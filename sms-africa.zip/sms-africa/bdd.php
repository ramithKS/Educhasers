<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=sayatech_sms;charset=utf8', 'sayatech_sms', 'Sayatech@786');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}