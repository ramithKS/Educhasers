<?php
session_start();
unset($_SESSION['admin']);
unset($_SESSION['student']);
unset($_SESSION['parent']);
unset($_SESSION['teacher']);
session_destroy();

header("Location: index.php");
exit;
?>