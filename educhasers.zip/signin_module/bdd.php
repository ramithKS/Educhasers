<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12536981_edu;charset=utf8', 'id12536981_admin', 'dbmsProject');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}