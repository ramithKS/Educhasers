<?php
	$conn = mysqli_connect("localhost","id12536981_admin","dbmsProject","id12536981_edu");
	if (!$conn) 
	{
	die("Connection failed: " . mysqli_connect_error());
	}
?>