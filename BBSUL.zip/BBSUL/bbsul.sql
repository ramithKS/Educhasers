-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2018 at 08:19 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbsul`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(3) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'Admin@BBSUL.com', 'Authourityofadmin');

-- --------------------------------------------------------

--
-- Table structure for table `alumini`
--

CREATE TABLE `alumini` (
  `id` int(255) NOT NULL,
  `name` varchar(300) NOT NULL,
  `batch` varchar(300) NOT NULL,
  `depart` varchar(300) NOT NULL,
  `doc` varchar(300) NOT NULL,
  `img` varchar(300) NOT NULL,
  `comp` varchar(300) NOT NULL,
  `post` varchar(300) NOT NULL,
  `contact` varchar(300) NOT NULL,
  `proposal` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumini`
--

INSERT INTO `alumini` (`id`, `name`, `batch`, `depart`, `doc`, `img`, `comp`, `post`, `contact`, `proposal`) VALUES
(1, 'Umer Memon', '3RD', 'Information Technology', 'Project Proposal.docx', 'ex1.png', 'Mars Enterprises', 'IT Manager', '+923078167730', 'BBSUL Student portal'),
(2, 'Salman Saeed', '4TH', 'Computer Science', 'Project Proposal.docx', 'salman.jpg', 'Aptech', 'Faculty Member', '+923042101203', '3D Game'),
(6, 'Sawli Khan', '3RD', 'Information Technology', 'Project Proposal.docx', '7.jpg', 'Huawei', 'IT Manager', '0302-xxx-xxxx', 'BBSUL Student Portal'),
(7, 'Imran Ahsan', '3RD', 'Information Technology', 'Project Proposal.docx', '26219861_1202063993257026_1665270859219727144_n.jpg', 'EOBI', 'Developer', '0302-xxx-xxxx', 'BBSUL Student Portal');

-- --------------------------------------------------------

--
-- Table structure for table `annoucements`
--

CREATE TABLE `annoucements` (
  `id` int(255) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `Source` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `annoucements`
--

INSERT INTO `annoucements` (`id`, `Description`, `Source`) VALUES
(1, 'HEC - Needs Based Scholarship Program (Spring-2017) (For Students of Morning Programs only)', 'NBS_form.pdf'),
(2, 'PM Laptop Scheme Phase 4 & 5 (Provisional List)', 'PM Laptop Scheme Phase 4 & 5 (Provisional List).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Writter` varchar(255) NOT NULL,
  `File` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `Name`, `Writter`, `File`, `thumbnail`) VALUES
(1, 'SOFTWARE TESTING AND QUALITY ASSURANCE Theory and Practice', 'KSHIRASAGAR NAIK / PRIYADARSHI TRIPATHY', 'STQA.pdf', 'STQA.png'),
(2, 'Software Quality Assurance', 'Daniel Galin', 'SQA.pdf', 'SQA.png'),
(12, 'Javaâ„¢ How to Program, Seventh Edition', 'Ditiel & Ditiel', 'JavaHowtoProgram7thEd.pdf', 'thumb.png');

-- --------------------------------------------------------

--
-- Table structure for table `new feed`
--

CREATE TABLE `new feed` (
  `id` int(3) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `new feed`
--

INSERT INTO `new feed` (`id`, `thumbnail`, `caption`) VALUES
(11, 'allama.jpg', 'ALLAMA-IQBAL Day Celebration on dd/mm/yy at 00:00am'),
(12, 'Dg.jpg', 'DG-Rangers Visit on dd/mm/yy at 00:00am');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(255) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `sessional` varchar(300) NOT NULL,
  `mid` varchar(300) NOT NULL,
  `final` varchar(300) NOT NULL,
  `hour` varchar(300) NOT NULL,
  `std_id` varchar(300) NOT NULL,
  `semester` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `subject`, `sessional`, `mid`, `final`, `hour`, `std_id`, `semester`) VALUES
(18, 'C Language', '18', '8', '26', '3', '3', '1'),
(19, 'F.Accounting', '20', '10', '30', '2', '3', '1'),
(20, 'Calculas', '20', '10', '20', '2', '3', '1'),
(21, 'ICT', '22', '16', '21', '3', '3', '1'),
(22, 'English', '16', '16', '27', '2', '3', '1'),
(23, 'Islamiat', '16', '16', '25', '2', '3', '1'),
(24, 'Calculas', '20', '20', '40', '3', '3', '1'),
(25, 'CS-405 C', '20', '16', '20', '3', '3', '1'),
(26, 'CS-405 SOFT ENGG', '13', '23', '34', '2', '3', '1');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(255) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `hash` varchar(300) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `profile` varchar(300) NOT NULL,
  `father_name` varchar(300) NOT NULL,
  `semester` varchar(300) NOT NULL,
  `department` varchar(300) NOT NULL,
  `feevoucher` varchar(300) NOT NULL,
  `feesdes` varchar(300) NOT NULL,
  `1final_marks` varchar(300) NOT NULL,
  `1_attend` varchar(300) NOT NULL,
  `2final_marks` varchar(300) NOT NULL,
  `2_attend` varchar(300) NOT NULL,
  `3final_marks` varchar(300) NOT NULL,
  `3_attend` varchar(300) NOT NULL,
  `4final_marks` varchar(300) NOT NULL,
  `4_attend` varchar(300) NOT NULL,
  `5final_marks` varchar(300) NOT NULL,
  `5_attend` varchar(300) NOT NULL,
  `6final_marks` varchar(300) NOT NULL,
  `6_attend` varchar(300) NOT NULL,
  `7final_marks` varchar(300) NOT NULL,
  `7_attend` varchar(300) NOT NULL,
  `8final_marks` varchar(300) NOT NULL,
  `status` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `8_attend` varchar(300) NOT NULL,
  `valid` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `email`, `password`, `hash`, `active`, `profile`, `father_name`, `semester`, `department`, `feevoucher`, `feesdes`, `1final_marks`, `1_attend`, `2final_marks`, `2_attend`, `3final_marks`, `3_attend`, `4final_marks`, `4_attend`, `5final_marks`, `5_attend`, `6final_marks`, `6_attend`, `7final_marks`, `7_attend`, `8final_marks`, `status`, `last_name`, `8_attend`, `valid`) VALUES
(3, 'umer memon', 'umerp66@gmail.com', '$2y$10$a5VFo6ZRDpIIbIVOGvVGHegx1d8v8.gDoilR0PJ3kG8khc.2yxfhm', '903ce9225fca3e988c2af215d4e544d3', 1, 'umer memon.png', 'Abdul Razzaq Memon', '3RD', 'BSIT', 'fee voucher.pdf', '4th-Semester Voucher', '2.30 GPA', '80%', '2.20 CGPA', '90%', '2.50 CGPA', '85%', '', '79%', '', '80%', '', '', '', '', '', 'Active', '156BSIT/17-5/3', '', '2018-11-14'),
(36, 'Sawli', 'sawlikhan280@gmail.com', '$2y$10$Nxetx4Z7LNLLe3JA/KpYFecTlbP5zFfwhOtl/B.E062Sfs/v472qe', 'c8ffe9a587b126f152ed3d89a146b445', 1, 'sawli khan.png', 'Imrad', '3RD', 'BSIT', '', '', '2.0 GPA', '', '2.5 CGPA', '', '2.7 CGPA', '', '', '', '', '', '', '', '', '', '', '', '173BSIT/17-5/3', '', ''),
(37, 'Manahil', 'manahil221@gmail.com', '$2y$10$HbfXqADLpPOpS3888RBLieN4GW8Sgb4A51KaDo0Oo3eKAHaEww2Wi', '9cf81d8026a9018052c429cc4e56739b', 1, 'IMG-20170325-WA0035.jpg', 'Sajjad Ali', '3RD', 'BSCS', '', '', '2.3 GPA', '', '2.6 CGPA', '', '2.9 CGPA', '', '', '', '', '', '', '', '', '', '', '', '181BSCS/17-5/3', '', ''),
(38, 'Imran', 'imran002@gmail.com', '$2y$10$lgMZUHw.ppDszi0t6ex.7OrTuFiZHDDECaFn2h73kXiCnjV0mYnKi', 'a5771bce93e200c36f7cd9dfd0e5deaa', 1, '26219861_1202063993257026_1665270859219727144_n.jpg', 'Ahsan', '3RD', 'BSCS', '', '', '2.3 GPA', '', '2.5 CGPA', '', '2.7 CGPA', '', '', '', '', '', '', '', '', '', '', '', '160BSCS/17-5/3', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(255) NOT NULL,
  `course` varchar(300) NOT NULL,
  `teacher` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `course`, `teacher`) VALUES
(2, 'CS-405 SOFT ENGG', '1'),
(3, 'CS-431 DES/A.ALG', '1'),
(4, 'CS-405 C', '4');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(255) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `username`, `password`) VALUES
(1, 'Ali_Orangzeb', 'teacher'),
(2, 'Muneeb Qureshi', 'networkingworld'),
(3, 'Abdul Haleem', 'mathsisworld'),
(4, 'Miss Nafeesa', 'C-language');

-- --------------------------------------------------------

--
-- Table structure for table `time table`
--

CREATE TABLE `time table` (
  `id` int(3) NOT NULL,
  `Updated` varchar(255) NOT NULL,
  `File` varchar(255) NOT NULL,
  `Time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `time table`
--

INSERT INTO `time table` (`id`, `Updated`, `File`, `Time`) VALUES
(1, 'Time-Table updated 6/5/2018', 'Time-Table.xlsx', '5:00pm'),
(2, 'Updated of 6//5/2018', 'updated.xlsx', '10:27pm'),
(3, 'Time Table new Updated', 'Time Table Spring -Final.xlsx', '4:53 AM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alumini`
--
ALTER TABLE `alumini`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `annoucements`
--
ALTER TABLE `annoucements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new feed`
--
ALTER TABLE `new feed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `1_mid` (`feesdes`),
  ADD KEY `1_mid_2` (`feesdes`),
  ADD KEY `feevoucher` (`feevoucher`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time table`
--
ALTER TABLE `time table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `alumini`
--
ALTER TABLE `alumini`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `annoucements`
--
ALTER TABLE `annoucements`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `new feed`
--
ALTER TABLE `new feed`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `time table`
--
ALTER TABLE `time table`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
