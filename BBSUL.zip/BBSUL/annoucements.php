<?php
/* Displays user information and some useful messages */
require 'db.php';
require 'cnc.php';
session_start();

// Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("Location: error.php");    
}
else {
    // Makes it easier to read
    $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
}
?>
<!DOCTYPE html>
<html lang="en" dir="">
<head>
    
    <title>Student Dashboard | CS-IT</title>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Optimum Linkup Universal Concepts" />
    <meta name="author" content="optimumlinkup.com.ng" />
    
    

<link rel="stylesheet" href="assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css">
<link rel="stylesheet" href="assets/css/font-icons/entypo/css/entypo.css">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
<link rel="stylesheet" href="assets/css/bootstrap.css">
<link rel="stylesheet" href="assets/css/neon-core.css">
<link rel="stylesheet" href="assets/css/neon-theme.css">
<link rel="stylesheet" href="assets/css/neon-forms.css">
<link rel="stylesheet" href="assets/css/skins/default.css">

<script src="assets/js/jquery-1.11.0.min.js"></script>

        <!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<link rel="shortcut icon" href="assets/images/favicon.png">
<link rel="stylesheet" href="assets/css/font-icons/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" href="assets/js/vertical-timeline/css/component.css">
<link rel="stylesheet" href="assets/js/datatables/responsive/css/datatables.responsive.css">


<!--Amcharts-->
<script src="http://localhost/sms/assets/js/amcharts/amcharts.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/pie.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/serial.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/gauge.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/funnel.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/radar.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/exporting/amexport.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/exporting/rgbcolor.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/exporting/canvg.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/exporting/jspdf.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/exporting/filesaver.js" type="text/javascript"></script>
<script src="http://localhost/sms/assets/js/amcharts/exporting/jspdf.plugin.addimage.js" type="text/javascript"></script>

<script>
    function checkDelete()
    {
        var chk=confirm("Are You Sure To Delete This !");
        if(chk)
        {
          return true;  
        }
        else{
            return false;
        }
    }
</script>   
</head>
<body class="page-body skin-default" >
    <div class="page-container " >
        <div class="sidebar-menu">
    <header class="logo-env" >

        <!-- logo -->
        <?php
  $product_array = $db_handle->runQuery("SELECT * FROM `students` WHERE email = '$email'");
  if (!empty($product_array)) { 
  foreach($product_array as $key=>$value){
?>  
        <div class="logo" style="">
            <a href="#">
                <img src="profile/<?php echo $product_array[$key]["profile"]; ?>"  style="max-height:60px; border-radius: 200px;float: left;"/>
            </a> &nbsp;
            <h4 style="color: white;float: right;margin-top: 15%;">Dashboard</h4>
        </div>
        <?php }}?>
        <!-- logo collapse icon -->
        <div class="sidebar-collapse" style="">
            <a href="#" class="sidebar-collapse-icon with-animation">

                <i class="entypo-menu"></i>
            </a>
        </div>

        <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
        <div class="sidebar-mobile-menu visible-xs">
            <a href="#" class="with-animation">
                <i class="entypo-menu"></i>
            </a>
        </div>
    </header>

    <div style=""></div>    
    <ul id="main-menu" class="">
        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->


        <!-- DASHBOARD -->
        <li class="">
            <a href="profile.php">
                <i class="entypo-gauge"></i>
                <span>New Feeds</span>
            </a>
        </li>
        
 <!-- ENQUIRY TABLE INFO -->
        <li class=" ">
            <a href="courses.php">
                <i class="entypo-book"></i>
                <span>Courses (CS-IT)</span>
            </a>
        </li>

        <!-- TEACHER -->
        <li class=" ">
            <a href="Records.php">
                <i class="entypo-users"></i>
                <span>Records</span>
            </a>
        </li>
         <!-- ACCOUNTANT -->
        <li class=" ">
            <a href="your_profile.php">
                <i class="entypo-users"></i>
                <span>Profile</span>
            </a>
        </li>
         
        <!-- CLASS ROUTINE -->
        <li class=" active">
            <a href="annoucements.php">
                <i class="entypo-target"></i>
                <span>Annoucements</span>
            </a>
        </li>
        
         <!-- CLUB -->
        <li class=" ">
            <a href="fee.php">
                <i class="fa fa-book"></i>
                <span>Fee Vouchers</span>
            </a>
        </li>
        
                 <!-- CIRCULAR MANAGER -->
                <li class="">
                    <a href="Time-Table.php">
                        <span><i class="entypo-book"></i>Time Tables</span>
                    </a>
                </li>
         <!-- STUDY MATERIALS -->
        <li class=" ">
            <a href="Books.php">
                <i class="entypo-target"></i>
                <span>Digital-Library</span>
            </a>
        </li>

        <!-- DAILY ATTENDANCE -->
        <li class=" ">
            <a href="attendence.php">
                <i class="entypo-chart-area"></i>
                <span>Attendances</span>
            </a>
        </li>
        
         <!-- EXAMS -->
        <li class=" ">
            <a href="result.php">
                <i class="entypo-graduation-cap"></i>
                <span>View Result</span>
            </a>
        </li>
        <li class=" ">
            <a href="alumni.php">
                <i class="entypo-graduation-cap"></i>
                <span>Alumni</span>
            </a>
        </li>
        <li class="sep"></li>
            
            <li>
                <a href="logout.php">
                    Log Out <i class="entypo-logout right"></i>
                </a>
            </li>
    </ul>

</div>
        <div class="main-content">
        
            <div class="row">
    
    <div class="col-md-12 col-sm-12 clearfix" style="text-align:center;">
        <h2 style="font-weight:200; margin:0px; color:#cac5be">BBSUL's News</h2>
    </div>
    
    <!-- Raw Links -->
    <div class="col-md-12 col-sm-12 clearfix ">
        
            </li>
            
        </ul>               
    </div>
    <br>  
</div>
<hr style="margin-top:0px;" />
  <div class="form">
          <p>
          <?php 
     
          // Display message about account verification link only once
          if ( isset($_SESSION['message']) )
          {
              echo $_SESSION['message'];
              
              // Don't annoy the user with more messages upon page refresh
              unset( $_SESSION['message'] );
          }
          
          ?>
          </p>
          
          <?php
          
          // Keep reminding the user this account is not active, until they activate
          if ( !$active ){
              echo
              '<div class="info"><br>
              Account is unverified, please confirm your email by clicking
              on the email link!
              </div>'.'<h3 style="color: red;text-align: center;">Account Is unverified, you cant see anything in the portal<br>
            Check your mailbox first and verify it.
        <span style="color: grey">Thanks</span>
        </h3>';
          }
          
          ?>
          
          
          <br><br>
          <h3 style="text-align: center;box-shadow: 2px 5px 10px 2px rgba(134,45,15,0.1);">Campus New / Updates</h3>




          <?php
  $product_array = $db_handle->runQuery("SELECT * FROM `Annoucements` Order by id DESC");
  if (!empty($product_array)) { 
  foreach($product_array as $key=>$value){
    if ($active == 1) {
        
?> 

            <div class="list-group">
                <marquee direction="right" behavior="alternate" style="border:solid">
  
            <a href="admin/files/<?php echo $product_array[$key]["Source"]; ?>" class="list-group-item" target="blank">  
            <h4><?php echo $product_array[$key]["Description"]; ?></h4>   
        </a></a>
</marquee>
    </div>
     <?php   }else{} ?>
        <?php }}?>


    </div>



            <style>
#chartdiv {
    width       : 100%;
    height      : 250px;
    font-size   : 11px;
}                           
</style>

<!-- Resources -->
<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script src="https://www.amcharts.com/lib/3/pie.js"></script>
<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>

<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script src="https://www.amcharts.com/lib/3/serial.js"></script>
<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>

<style>
#chartdiv2 {
    width       : 100%;
    height      : 250px;
    font-size   : 11px;
}                   
.style2 {font-size: 24px}
</style>


    <link rel="stylesheet" href="assets/js/datatables/responsive/css/datatables.responsive.css">
    <link rel="stylesheet" href="assets/js/select2/select2-bootstrap.css">
    <link rel="stylesheet" href="assets/js/select2/select2.css">
    <link rel="stylesheet" href="assets/js/selectboxit/jquery.selectBoxIt.css">

    <!-- Bottom Scripts -->
    <script src="assets/js/gsap/main-gsap.js"></script>
    <script src="assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/joinable.js"></script>
    <script src="assets/js/resizeable.js"></script>
    <script src="assets/js/neon-api.js"></script>
    <script src="assets/js/toastr.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/fullcalendar/fullcalendar.min.js"></script>
    <script src="assets/js/bootstrap-datepicker.js"></script>
    <script src="assets/js/fileinput.js"></script>
    
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/datatables/TableTools.min.js"></script>
    <script src="assets/js/dataTables.bootstrap.js"></script>
    <script src="assets/js/datatables/jquery.dataTables.columnFilter.js"></script>
    <script src="assets/js/datatables/lodash.min.js"></script>
    <script src="assets/js/datatables/responsive/js/datatables.responsive.js"></script>
    <script src="assets/js/select2/select2.min.js"></script>
    <script src="assets/js/selectboxit/jquery.selectBoxIt.min.js"></script>

    
    <script src="assets/js/neon-calendar.js"></script>
    <script src="assets/js/neon-chat.js"></script>
    <script src="assets/js/neon-custom.js"></script>
    <script src="assets/js/neon-demo.js"></script>


<!-- SHOW TOASTR NOTIFIVATION -->


<!-----  DATA TABLE EXPORT CONFIGURATIONS ---->                      
<script type="text/javascript">

    jQuery(document).ready(function($)
    {
        

        var datatable = $("#table_export").dataTable();
        
        $(".dataTables_wrapper select").select2({
            minimumResultsForSearch: -1
        });
    });
        
</script>    


<?php  ?>




</body>
</html>