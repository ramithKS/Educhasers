<?php 
/* Main page with two forms: sign up and log in */
require 'db.php';
require 'cnc.php';
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" href="Images/logo1.PNG" />
  <title>Student Portal(CS-IT)</title>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Optimum Linkup Universal Concepts" />
    <meta name="author" content="optimumlinkup.com.ng" />
  <?php include 'css/css.html'; ?>
  <link rel="stylesheet" type="text/css" href="css/style1.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/responsive.css">
	<script src="js/jsquery.min.js"></script>   
	<script src="js/jquery.flexslider-min.js"></script> 
	<script src="js/jquery.fancybox.pack.js"></script>   
	<script src="js/main.js"></script> 
	<script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/color/rose.css">
	<link rel="stylesheet" type="text/css" href="library/font-awesome-4.3.0/css/font-awesome.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<style type="text/css">
	a:hover{
		text-decoration: none;
		color: lightblue;
	}
  label{
    color: grey;
  }
  body{
  	background: url('Images/wall.jpg');
  	background-repeat: no-repeat;
  	background-size: cover;
  	background-attachment: fixed;
  }
</style>
<script>
function alertUser(msg) {
alert(msg);
}
var rejectList = [ "google.com" , "yahoo.net" ];

function validateEmailField()
{
var emailValue = $('#email-input').val(); // To Get Value (can use getElementById)
var splitArray = emailValue.split('@'); // To Get Array

if(rejectList.indexOf(splitArray[1]) >= 0)
{
// Means it has the rejected domains
return false;
alert('Wrogn Email');
}
return true;

}
</script>
<style type="text/css">
 .col-md-3:hover{
    box-shadow: 2px 5px 10px 2px rgba(134,45,15,0.1);
    opacity: 0.9;
    stroke: #4274D3;
 }
 .form-control{
 	height: 40px;
 	background: #f5f5f5;
 	color: #333;
 }
 </style>    
</head>

<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['login'])) { //user logging in

        require 'login.php';
        
    }
    
    elseif (isset($_POST['register'])) { //user registering
        
        require 'register.php';
        
    }
}
?>
<!-- onload="alertUser('Be Sure! You are the Student of BBSUL.!')" -->
<body>
  <!--Add the following script at the bottom of the web page (before </body></html>)-->
<script type="text/javascript">function add_chatinline(){var hccid=22349555;var nt=document.createElement("script");nt.async=true;nt.src="https://mylivechat.com/chatinline.aspx?hccid="+hccid;var ct=document.getElementsByTagName("script")[0];ct.parentNode.insertBefore(nt,ct);}
add_chatinline();</script>

	<!--Start Nav-bar!-->
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><h3>BBSUL-PORTAL</h3></a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="index.php">Student-Portal</a></li>
      <li class="active"><a href="alumini.php">BBSUL-Alumni</a></li>
      <li><a href="alumini_reg.php">Alumni-Registration</a></li>
    </ul>
  </div>
</nav>
		<!--End!-->
 
    <div class="container">
      
      <input class="form-control" id="myInput" type="text" placeholder="Search Students / Batches / Proposals / Departments" >
  <br>
     <div class="row">
       <?php
  $product_array = $db_handle->runQuery("SELECT * FROM `alumini` Order by id DESC");
  if (!empty($product_array)) { 
  foreach($product_array as $key=>$value){
?>  
            <!-- Start -->
            <div id="myTable">
           <div class="col-md-3">

        <div class="thumbnail" style="height: 450px;background: #fbfbff;font-size: 15.5px;font-family: oswald;">

        <center><img src="profile/<?php echo $product_array[$key]["img"]; ?>"  alt="Nature" style="height: 130px;width: 135px;border-radius: 100%;margin-top: 15px;" ></center>
        <div class="caption">
        <center><p style="border-top: 1px solid #333;padding-top: 5px;color: #000;"><b style="color: #111">Student-Name:</b> <?php echo $product_array[$key]["name"]; ?>
            <br>
            <b style="color: #111">Department: </b><?php echo $product_array[$key]["depart"]; ?>
            <br>
            <b style="color: #111">Batch: </b><?php echo $product_array[$key]["batch"]; ?>
            <br>
            <b style="color: #111">Proposal: </b><?php echo $product_array[$key]["proposal"]; ?>
            <br><br><hr>
            <b style="color: green;">CURRENT STATUS</b><hr>
            <p style="color: #333;">
            <b style="color: #111">Company: </b><?php echo $product_array[$key]["comp"]; ?>
            <br>
            <b style="color: #111">Designation: </b><?php echo $product_array[$key]["post"]; ?>
            <br>
            <b style="color: #111">Email: </b><?php echo $product_array[$key]["contact"]; ?>
            </p>
            <br>
            <a href="alumini/<?php echo $product_array[$key]["doc"]; ?>" class="btn btn-primary" style="border-radius: 5px;">Download CV</a>
        </p></center>
        </div>
        </div>
        </div></div>
        <!-- end -->
        <?php }}?>
 

    </div></div>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

    <!--Start footer!-->
<footer class="site-footer section-spacing text-center " id="eight">
    
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <p class="footer-links"><a href="#">Terms of Use</a> <a href="#">Privacy Policy</a></p>
      </div>
      <div class="col-md-4"> <small>&copy; 2018 BBSUL. All rights reserved.</small></div>
      <div class="col-md-4"> 
        <!--social-->
        
        <ul class="social">
          <li><a href="https://www.facebook.com/Controller.WAU/" target="_blank"><i class="fa fa-facebook"></i></a></li>
          <li><a href="https://www.youtube.com/channel/UCsuyUBuNTiRhPTJLFN0ckEQ" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
        </ul></div></div></div></footer>
        
        <!--social end--> 
    <script src='js/jquery.min.js'></script>

    <script src="js/index.js"></script>
</body>
</html>