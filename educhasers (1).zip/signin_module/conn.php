<?php
	$conn = mysqli_connect("localhost","id12809399_admin","dbmsProject","id12809399_edu");
	if (!$conn) 
	{
	die("Connection failed: " . mysqli_connect_error());
	}
?>